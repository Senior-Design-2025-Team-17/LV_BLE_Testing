//
//  LV_BLE_testingApp.swift
//  LV_BLE_testing
//
//  Created by Sydney Chang on 3/23/25.
//

import SwiftUI

@main
struct LV_BLE_testingApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
